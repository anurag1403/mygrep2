#include<stdio.h>
#define MAX 100000
int match(int, char **);
int imatch(int, char **);
int nextlines(int, char **);
int beforelines(int, char **);
int neighbourlines(int, char **);
int wholeword(int, char **);
int invert(int, char **);
int matchcount(int, char **);
int invertcount(int, char **);
int allfiles(int, char **, char *);
