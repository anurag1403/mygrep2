#include<stdio.h>
#include"features.h"
#include<string.h>
#include<errno.h>
#include<stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include<unistd.h>
int match(int argc, char *argv[]) {
	char *newl;
	char line[MAX];
	int i, j, k, line1, file1, max, flag = 0;
	FILE *fp;
	fp = fopen(argv[2], "r");
	if(fp == NULL) { 
		perror("ERROR:");
		return errno;
	}
	while((fgets(line, MAX, fp)) != NULL) {
		newl = strchr(line, '\n');
		*newl = '\0';
		line1 = strlen(line);
		file1 = strlen(argv[1]);
		max = line1 - file1 + 1;
		for(i = 0; i < max; i++) {
			k = i;
			for(j = 0; j < file1; j++) {
				if(line[k] != argv[1][j]) {
					break;
				}
				k++;
				if(j == (file1 - 1)) {
					printf("%s : %s\n", argv[2], line);
					flag++;
					break;
				}
			}
			if(flag == 1) {
				flag = 0;
				break;
			}
		}
	}
	fclose(fp);
	return 0;
}
int imatch(int argc, char *argv[]) {
	char *newl;
	char line[MAX];
	int i, j, k, line1, file1, max, flag = 0, ascii;
	FILE *fp;
	fp = fopen(argv[3], "r");
	if(fp == NULL) { 
		perror("ERROR:");
		return errno;
	}
	while((fgets(line, MAX, fp)) != NULL) {
		newl = strchr(line, '\n');
		*newl = '\0';
		line1 = strlen(line);
		file1 = strlen(argv[2]);
		max = line1 - file1 + 1;
		for(i = 0; i < max; i++) {
			k = i;
			for(j = 0; j < file1; j++) {
				ascii = line[k] - argv[2][j]; 
				if(ascii == 0 || ascii == -32 || ascii == 32) {
					k++;
				}
				else
					break;
				if(j == (file1 - 1)) {
					printf("%s : %s\n", argv[3], line);
					flag++;
					break;
				}
			}
			if(flag == 1) {
				flag = 0;
				break;
			}
		}
	}
	fclose(fp);
	return 0;
}
int nextlines(int argc, char *argv[]) {
	char *newl;
	char line[MAX];
	int i, j, k, line1, file1, max, flag = 0, ar2;
	FILE *fp;
	fp = fopen(argv[4], "r");
	if(fp == NULL) { 
		perror("ERROR:");
		return errno;
	}
	ar2 = atoi(argv[2]);
	while((fgets(line, MAX, fp)) != NULL) {
		newl = strchr(line, '\n');
		*newl = '\0';
		line1 = strlen(line);
		file1 = strlen(argv[3]);
		max = line1 - file1 + 1;
		for(i = 0; i < max; i++) {
			k = i;
			for(j = 0; j < file1; j++) {
				if(line[k] != argv[3][j]) {
					break;
				}
				k++;
				if(j == (file1 - 1)) {
					printf("%s : %s\n", argv[4], line);
					flag++;
					break;
				}
			}
			if(flag == 1) {
				flag = 2;
				break;
			}
		}
		if(flag == 2)
			break;
	}
	while((fgets(line, MAX, fp) != NULL) && ar2 > 0) {
		newl = strchr(line, '\n');
		*newl = '\0';
		printf("%s : %s\n", argv[4], line);
		ar2--;
	}
	fclose(fp);
	return 0;
}
int beforelines(int argc, char *argv[]) {
	char *newl, *line[100000];
	int i, j, k, line1, file1, max, flag = 0, ar2, l = 0, m = 100000, n;
	FILE *fp;
	fp = fopen(argv[4], "r");
	if(fp == NULL) { 
		perror("ERROR:");
		return errno;
	}
	while(m > 0) {
		line[l] = (char*)malloc(sizeof(char) * 100000);
		l++;
		m--;
	}
	line[l] = (char*)malloc(sizeof(char) * 100000);
	l = 0;
	rewind(fp);
	ar2 = atoi(argv[2]);
	while((fgets(line[l], 100000, fp)) != NULL) {
		newl = strchr(line[l], '\n');
		*newl = '\0';
		line1 = strlen(line[l]);
		file1 = strlen(argv[3]);
		max = line1 - file1 + 1;
		for(i = 0; i < max; i++) {
			k = i;
			for(j = 0; j < file1; j++) {
				if(line[l][k] != argv[3][j]) {
					break;
				}
				k++;
				if(j == (file1 - 1)) {
					flag++;
					break;
				}
			}
			if(flag == 1) {
				flag = 2;
				break;
			}
		}
		if(flag == 2)
			break;
		l++;
	}
	n = l - ar2;
	if(n > 0) {
		while(n <= l) {
			printf("%s : %s\n", argv[4], line[n]);
			n++;
		}
	}
	else {
		n = 0;
		while(n <= l) {
			printf("%s : %s\n", argv[4], line[n]);
			n++;
		}
	}
	fclose(fp);
	return 0;
}
int neighbourlines(int argc, char *argv[]) {
	char *newl, *line[100000];
	int i, j, k, line1, file1, max, flag = 0, ar2, l = 0, m = 100000, n;
	FILE *fp;
	fp = fopen(argv[4], "r");
	if(fp == NULL) { 
		perror("ERROR:");
		return errno;
	}
	while(m > 0) {
		line[l] = (char*)malloc(sizeof(char) * 100000);
		l++;
		m--;
	}
	l = 0;
	rewind(fp);
	ar2 = atoi(argv[2]);
	while((fgets(line[l], 100000, fp)) != NULL) {
		newl = strchr(line[l], '\n');
		*newl = '\0';
		line1 = strlen(line[l]);
		file1 = strlen(argv[3]);
		max = line1 - file1 + 1;
		for(i = 0; i < max; i++) {
			k = i;
			for(j = 0; j < file1; j++) {
				if(line[l][k] != argv[3][j]) {
					break;
				}
				k++;
				if(j == (file1 - 1)) {
					flag++;
					break;
				}
			}
			if(flag == 1) {
				flag = 2;
				break;
			}
		}
		if(flag == 2)
			break;
		l++;
	}
	n = l - ar2;
	if(n > 0) {
		while(n <= l) {
			printf("%s : %s\n", argv[4], line[n]);
			n++;
		}
		while(((fgets(line[l + 1], MAX, fp)) != NULL) && ar2 > 0) {
			newl = strchr(line[l + 1], '\n');
			*newl = '\0';
			printf("%s : %s\n", argv[4], line[l + 1]);
			ar2--;
		}
	}
	else {
		n = 0;
		while(n <= l) {
			printf("%s : %s\n", argv[4], line[n]);
			n++;
		}
		while(((fgets(line[l + 1], MAX, fp)) != NULL) && ar2 > 0) {
			newl = strchr(line[l + 1], '\n');
			*newl = '\0';
			printf("%s : %s\n", argv[4], line[l + 1]);
			ar2--;
		}
	}
	fclose(fp);
	return 0;
}
int wholeword(int argc, char *argv[]) {
	char *newl;
	char line[MAX];
	int i, j, k, line1, file1, max, flag = 0;
	FILE *fp;
	fp = fopen(argv[3], "r");
	if(fp == NULL) { 
		perror("ERROR:");
		return errno;
	}
	while((fgets(line, MAX, fp)) != NULL) {
		newl = strchr(line, '\n');
		*newl = '\0';
		line1 = strlen(line);
		file1 = strlen(argv[2]);
		max = line1 - file1 + 1;
		for(i = 0; i < max; i++) {
			k = i;
			for(j = 0; j < file1; j++) {
				if(line[k] != argv[2][j]) {
					break;
				}
				k++;
				if(j == (file1 - 1) && (line[k] == ' ' || line[k] == '\0') && line[i - 1] == ' ') {
					printf("%s : %s\n", argv[2], line);
					flag++;
					break;
				}
			}
			if(flag == 1) {
				flag = 0;
				break;
			}
		}
	}
	fclose(fp);
	return 0;
}
int invert(int argc, char *argv[]) {
	char *newl;
	char line[MAX];
	int i, j, k, line1, file1, max, flag = 0,count = 0;
	FILE *fp;
	fp = fopen(argv[3], "r");
	if(fp == NULL) { 
		perror("ERROR:");
		return errno;
	}
	while((fgets(line, MAX, fp)) != NULL) {
		newl = strchr(line, '\n');
		*newl = '\0';
		count = 0;
		line1 = strlen(line);
		file1 = strlen(argv[2]);
		max = line1 - file1 + 1;
		for(i = 0; i < max; i++) {
			k = i;
			for(j = 0; j < file1; j++) {
				if(line[k] != argv[2][j]) {
					break;
				}
				k++;
				if(j == (file1 - 1)) {
					flag++;
					count++;
					break;
				}
			}
			if(flag == 1) {
				flag = 0;
				break;
			}
		}
		if(count == 0)
			printf("%s : %s\n", argv[3], line);
	}
	fclose(fp);
	return 0;
}
int matchcount(int argc, char *argv[]) {
	char *newl;
	char line[MAX];
	int i, j, k, line1, file1, max, flag = 0, count = 0;
	FILE *fp;
	fp = fopen(argv[3], "r");
	if(fp == NULL) { 
		perror("ERROR:");
		return errno;
	}
	while((fgets(line, MAX, fp)) != NULL) {
		newl = strchr(line, '\n');
		*newl = '\0';
		line1 = strlen(line);
		file1 = strlen(argv[2]);
		max = line1 - file1 + 1;
		for(i = 0; i < max; i++) {
			k = i;
			for(j = 0; j < file1; j++) {
				if(line[k] != argv[2][j]) {
					break;
				}
				k++;
				if(j == (file1 - 1)) {
					count++;
					flag++;
					break;
				}
			}
			if(flag == 1) {
				flag = 0;
				break;
			}
		}
	}
	printf("%d\n", count);
	fclose(fp);
	return 0;
}
int invertcount(int argc, char *argv[]) {
	char *newl;
	char line[MAX];
	int i, j, k, line1, file1, max, flag = 0,count = 0, number = 0;
	FILE *fp;
	fp = fopen(argv[4], "r");
	if(fp == NULL) { 
		perror("ERROR:");
		return errno;
	}
	while((fgets(line, MAX, fp)) != NULL) {
		newl = strchr(line, '\n');
		*newl = '\0';
		count = 0;
		line1 = strlen(line);
		file1 = strlen(argv[3]);
		max = line1 - file1 + 1;
		for(i = 0; i < max; i++) {
			k = i;
			for(j = 0; j < file1; j++) {
				if(line[k] != argv[3][j]) {
					break;
				}
				k++;
				if(j == (file1 - 1)) {
					flag++;
					count++;
					break;
				}
			}
			if(flag == 1) {
				flag = 0;
				break;
			}
		}
		if(count == 0)
			number++;
	}
	printf("%d\n", number);
	fclose(fp);
	return 0;
}
int allfiles(int argc, char *argv[], char *path) {
	char *newl;
	char line[MAX];
	int i, j, k, line1, file1, max, flag = 0;
	FILE *fp;
	DIR* dir;
	struct dirent *dirEntry;
	struct stat inode;
	char name[MAX];
	dir = opendir(path);
	if (dir == 0) {
		perror ("ERROR:");
		return errno;
	}
	while((dirEntry = readdir(dir)) != 0) {
		//sprintf(name,"%s%s", path, dirEntry->d_name); 
		lstat (dirEntry->d_name, &inode);
		//printf("%s\n",dirEntry->d_name);
		if (S_ISREG(inode.st_mode)) {
			printf("file:%s\n",dirEntry->d_name);
			fp = fopen(dirEntry->d_name, "r");
			if(fp == NULL) { 
				perror("ERROR:");
				return errno;
			}
			while((fgets(line, MAX, fp)) != NULL) {
				newl = strchr(line, '\n');
				*newl = '\0';
				line1 = strlen(line);
				file1 = strlen(argv[1]);
				max = line1 - file1 + 1;
				for(i = 0; i < max; i++) {
					k = i;
					for(j = 0; j < file1; j++) {
						if(line[k] != argv[1][j]) {
							break;
						}
						k++;
						if(j == (file1 - 1)) {
							printf("%s : %s\n", dirEntry->d_name, line);
							flag++;
							break;
						}
					}
					if(flag == 1) {
						flag = 0;
						break;
					}
				}
			}
			fclose(fp);
		}
		else if (S_ISDIR(inode.st_mode)) {
			 printf("dir:%s\n",dirEntry->d_name);
		}
	}
	closedir(dir);
}













